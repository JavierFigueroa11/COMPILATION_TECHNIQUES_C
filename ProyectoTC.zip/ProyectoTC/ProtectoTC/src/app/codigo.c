int funcionM(int c);

int funcionM(int c){
    c = c + 20;
    return c;
}

int main(){   

    int x;
    x = funcionM(20);
    
    int h;
    int i;
    
    for(i = 0; i < 20; i++){
        h = 3 * 20;
    }   

}